(function() {
  $(function() {
    TheNotification.show_notifications();
    return TheRoleEditInPlace.init();
  });

}).call(this);
